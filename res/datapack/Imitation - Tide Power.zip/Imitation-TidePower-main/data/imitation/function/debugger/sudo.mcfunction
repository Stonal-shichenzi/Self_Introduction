scoreboard players set @s debugger 2
